from intel.normalize import norm_text, split_asset_aliases


def test_asset_trial_matcher_compact_exact():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker

    from intel.db import Base
    from intel import models
    from intel.matching import AssetTrialMatcher

    engine = create_engine("sqlite:///:memory:", future=True)
    Base.metadata.create_all(bind=engine)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)

    with SessionLocal() as s:
        s.add(models.Company(id="c1", name="Co"))
        a = models.Asset(company_id="c1", canonical_name="JNJ-1234")
        s.add(a)
        s.flush()
        s.add(models.AssetAlias(asset_id=a.id, alias="JNJ-1234", alias_norm=norm_text("JNJ-1234")))
        s.commit()

        matcher = AssetTrialMatcher.build(s, "c1")
        m = matcher.match_terms(["JNJ 1234"])
        assert a.id in m
        assert m[a.id].match_details.get("strategy") in {"exact_compact", "fuzzy_compact", "fuzzy_norm"}

def test_norm_text():
    assert norm_text("DARZALEX (daratumumab)") == "darzalex daratumumab"

def test_split_asset_aliases():
    canonical, aliases = split_asset_aliases("JNJ-1900 (NBTXR3)")
    assert canonical == "JNJ-1900"
    assert any(a.upper() == "NBTXR3" for a in aliases)

if __name__ == "__main__":
    test_asset_trial_matcher_compact_exact()
    test_norm_text()
    test_split_asset_aliases()
    print("OK")
