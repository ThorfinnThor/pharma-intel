from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

from rapidfuzz import fuzz
from sqlalchemy import select
from sqlalchemy.orm import Session

from . import models
from .normalize import norm_text
from .settings import settings


_NON_ALNUM = re.compile(r"[^a-z0-9]+")


def _compact_norm(s: str) -> str:
    """Lowercase + remove all non-alphanumerics (hyphens/spaces/etc)."""
    return _NON_ALNUM.sub("", (s or "").strip().lower())


@dataclass(frozen=True)
class MatchResult:
    asset_id: int
    match_type: str  # exact|fuzzy
    match_score: int
    match_details: dict[str, Any]


class AssetTrialMatcher:
    """Tiered resolver from trial intervention terms -> internal assets."""

    def __init__(self, company_id: str, *,
                 alias_norm_to_asset: dict[str, int],
                 compact_to_assets: dict[str, set[int]],
                 asset_to_best_alias: dict[int, str],
                 alias_norm_to_alias: dict[str, str],
                 alias_items: list[tuple[str, int]],
                 alias_compact_items: list[tuple[str, str, int]]):
        self.company_id = company_id
        self.alias_norm_to_asset = alias_norm_to_asset
        self.compact_to_assets = compact_to_assets
        self.asset_to_best_alias = asset_to_best_alias
        self.alias_norm_to_alias = alias_norm_to_alias
        self.alias_items = alias_items
        # (alias_norm, alias_compact, asset_id) for contains-style matching
        self.alias_compact_items = alias_compact_items

    @classmethod
    def build(cls, session: Session, company_id: str) -> "AssetTrialMatcher":
        stmt = (
            select(models.AssetAlias.alias, models.AssetAlias.alias_norm, models.AssetAlias.asset_id)
            .join(models.Asset)
            .where(models.Asset.company_id == company_id)
        )
        alias_norm_to_asset: dict[str, int] = {}
        alias_norm_to_alias: dict[str, str] = {}
        compact_to_assets: dict[str, set[int]] = {}
        asset_to_best_alias: dict[int, str] = {}

        alias_items: list[tuple[str, int]] = []
        alias_compact_items: list[tuple[str, str, int]] = []
        for alias, alias_norm, aid in session.execute(stmt).all():
            aid_i = int(aid)
            alias_norm_to_asset[alias_norm] = aid_i
            alias_norm_to_alias[alias_norm] = str(alias)
            alias_items.append((alias_norm, aid_i))

            ac = _compact_norm(alias_norm)
            if ac:
                alias_compact_items.append((alias_norm, ac, aid_i))

            c = _compact_norm(alias_norm)
            if c:
                compact_to_assets.setdefault(c, set()).add(aid_i)

            # Prefer a short, "nice" alias for explainability
            cur = asset_to_best_alias.get(aid_i)
            if cur is None or (len(str(alias)) < len(cur)):
                asset_to_best_alias[aid_i] = str(alias)

        return cls(
            company_id,
            alias_norm_to_asset=alias_norm_to_asset,
            compact_to_assets=compact_to_assets,
            asset_to_best_alias=asset_to_best_alias,
            alias_norm_to_alias=alias_norm_to_alias,
            alias_items=alias_items,
            alias_compact_items=alias_compact_items,
        )

    def match_text(self, text: str, *, field: str = "title") -> dict[int, MatchResult]:
        """Match assets by scanning free text (titles/summaries) for aliases.

        This is critical for program codes where CTG may not include a clean intervention token,
        but the study title often includes the code.
        """
        t = (text or "").strip()
        if not t:
            return {}

        tn = norm_text(t)
        if not tn:
            return {}

        # Contains matching is done in two flavors:
        # - word-boundary-ish contains on normalized text
        # - compact contains for code-like tokens (hyphens/spaces removed)
        padded = f" {tn} "
        tc = _compact_norm(tn)

        out: dict[int, MatchResult] = {}

        def choose(existing: MatchResult | None, cand: MatchResult) -> MatchResult:
            if existing is None:
                return cand
            # Prefer higher score, then exact-ish types
            if cand.match_score > existing.match_score:
                return cand
            return existing

        for alias_norm, alias_compact, aid in self.alias_compact_items:
            if len(alias_norm) < 4:
                continue

            alias_disp = self.alias_norm_to_alias.get(alias_norm) or self.asset_to_best_alias.get(aid) or ""

            # Code-like: contains digits (e.g., JNJ-7446). Use compact contains.
            is_code = any(ch.isdigit() for ch in alias_norm)

            if is_code and alias_compact and tc and alias_compact in tc:
                out[aid] = choose(
                    out.get(aid),
                    MatchResult(
                        asset_id=aid,
                        match_type=f"{field}_contains",
                        match_score=97,
                        match_details={"field": field, "text": t, "matched_alias": alias_disp, "strategy": "contains_compact"},
                    ),
                )
                continue

            # Word-ish: require space-delimited contains
            needle = f" {alias_norm} "
            if needle in padded:
                score = 92
                out[aid] = choose(
                    out.get(aid),
                    MatchResult(
                        asset_id=aid,
                        match_type=f"{field}_contains",
                        match_score=score,
                        match_details={"field": field, "text": t, "matched_alias": alias_disp, "strategy": "contains_word"},
                    ),
                )

        return out

    def match_terms(self, terms: list[str]) -> dict[int, MatchResult]:
        """Return best match per asset_id (deduped)."""

        def rank(mt: str) -> int:
            return {"exact": 3, "fuzzy": 1}.get(mt, 0)

        def choose(existing: MatchResult | None, cand: MatchResult) -> MatchResult:
            if existing is None:
                return cand
            if rank(cand.match_type) > rank(existing.match_type):
                return cand
            if rank(cand.match_type) < rank(existing.match_type):
                return existing
            return cand if cand.match_score > existing.match_score else existing

        best: dict[int, MatchResult] = {}

        for term in terms:
            t = (term or "").strip()
            if not t:
                continue
            n = norm_text(t)
            if not n:
                continue

            # Tier 1: exact norm match
            if n in self.alias_norm_to_asset:
                aid = self.alias_norm_to_asset[n]
                alias = self.alias_norm_to_alias.get(n) or self.asset_to_best_alias.get(aid) or ""
                best[aid] = choose(
                    best.get(aid),
                    MatchResult(
                        asset_id=aid,
                        match_type="exact",
                        match_score=100,
                        match_details={"term": t, "matched_alias": alias, "strategy": "exact_norm"},
                    ),
                )
                continue

            # Tier 2: exact "compact" match (handles hyphen/space differences)
            cn = _compact_norm(n)
            if cn and cn in self.compact_to_assets:
                for aid in self.compact_to_assets[cn]:
                    alias = self.asset_to_best_alias.get(aid) or ""
                    best[aid] = choose(
                        best.get(aid),
                        MatchResult(
                            asset_id=aid,
                            match_type="exact",
                            match_score=98,
                            match_details={"term": t, "matched_alias": alias, "strategy": "exact_compact"},
                        ),
                    )
                continue

            # Tier 3: fuzzy match over normalized aliases
            best_aid: int | None = None
            best_alias_norm: str | None = None
            best_score = 0

            for alias_norm, aid in self.alias_items:
                # quick length gate
                if abs(len(alias_norm) - len(n)) > 18:
                    continue
                sc = max(
                    fuzz.token_set_ratio(n, alias_norm),
                    fuzz.ratio(n, alias_norm),
                    fuzz.partial_ratio(n, alias_norm),
                )
                if sc > best_score:
                    best_score = int(sc)
                    best_aid = aid
                    best_alias_norm = alias_norm

            # Optional: compact fuzzy (stricter)
            best_compact_aid: int | None = None
            best_compact_score = 0
            if cn:
                for alias_norm, aid in self.alias_items:
                    an = _compact_norm(alias_norm)
                    if not an:
                        continue
                    if abs(len(an) - len(cn)) > 10:
                        continue
                    sc = max(fuzz.ratio(cn, an), fuzz.partial_ratio(cn, an))
                    if sc > best_compact_score:
                        best_compact_score = int(sc)
                        best_compact_aid = aid

            # Choose strongest acceptable candidate
            if best_aid is not None and best_score >= settings.fuzzy_threshold:
                alias = (self.alias_norm_to_alias.get(best_alias_norm or "") or self.asset_to_best_alias.get(best_aid) or "")
                best[best_aid] = choose(
                    best.get(best_aid),
                    MatchResult(
                        asset_id=best_aid,
                        match_type="fuzzy",
                        match_score=int(best_score),
                        match_details={"term": t, "matched_alias": alias, "strategy": "fuzzy_norm", "score": int(best_score)},
                    ),
                )
                continue

            if best_compact_aid is not None and best_compact_score >= settings.fuzzy_threshold_compact:
                alias = self.asset_to_best_alias.get(best_compact_aid) or ""
                best[best_compact_aid] = choose(
                    best.get(best_compact_aid),
                    MatchResult(
                        asset_id=best_compact_aid,
                        match_type="fuzzy",
                        match_score=int(best_compact_score),
                        match_details={"term": t, "matched_alias": alias, "strategy": "fuzzy_compact", "score": int(best_compact_score)},
                    ),
                )

        return best
